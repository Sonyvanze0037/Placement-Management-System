package com.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Course1;



public class Course
{
	public static void main(String[] args) 
	{
		Configuration c= new Configuration();
		
		//
		SessionFactory sf=c.configure().buildSessionFactory();
	    //open the session
		Session session=sf.openSession();
		
		//beginig the transaction
	    Transaction tx= session.beginTransaction();
	    //create the object of class
	/*   Course1 c1=  new Course1();
	   Course1 c2=  new Course1();
	   Course1 c3=  new Course1();
	   Course1 c4=  new Course1();
	  */ 
	    Course1 c5=  new Course1();
	    
	    //set values of properties
	  /* c1.setId(1);
	   c1.setCname("Software Development");
	   c1.setC_duration(3);
	   c1.setC_completion(0);
	   
	   c2.setId(2);
	   c2.setCname("Software Testing");
	   c2.setC_duration(3);
	   c2.setC_completion(0);
	   
	   c3.setId(3);
	   c3.setCname("Web Development");
	   c3.setC_duration(4);
	   c3.setC_completion(0);
	   
	   c4.setId(4);
	   c4.setCname("Databse");
	   c4.setC_duration(3);
	   c4.setC_completion(0);*/
	   
	   c5.setId(5);
	   c5.setCname("html");
	   c5.setC_duration(3);
	   c5.setC_completion(0);  
	   
	 //  session.save(c1);
	 //  session.save(c2);
	//   session.save(c3);
	//   session.save(c4);
	   session.save(c5);
	   
	    //sf.close();
	    tx.commit();
	    System.out.println("done");

	}

}
