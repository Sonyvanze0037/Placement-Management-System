package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/StudUpdate")
public class StudUpdate extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		try 
		
		{
					
			Class.forName("com.mysql.jdbc.Driver");
		}
		
		catch(ClassNotFoundException e1)
		{
			e1.printStackTrace();
		}
		
		try
		{ 
			Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
			PreparedStatement ps= c.prepareStatement("update studregister  set stud_name=?, stud_email=?, stud_mob_no=? ,stud_degree=?, pass_year=? where stud_id=?");
			
			String studname =req.getParameter("stud_name");
			
			String studemail=req.getParameter("stud_email");
			

			String studmobno=req.getParameter("stud_mob_no");
			String studegree=req.getParameter("stud_degree");
			String studpassyear=req.getParameter("pass_year");
			
			String sid=req.getParameter("studid");
			int no1=Integer.parseInt(sid);
			
		
			
		
			ps.setString(1,studname);
			ps.setString(2,studemail);
			ps.setString(3,studmobno);
			ps.setString(4,studegree);
			ps.setString(5,studpassyear);
			
			ps.setInt(6, no1);
			ps.executeUpdate();
			System.out.println("data Updated succesfully");
			
			resp.sendRedirect("viewallstudent.jsp");
			
			} 
		

		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}