package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/TeachUpdate")
public class TeachUpdate extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		try 
		
		{
					
			Class.forName("com.mysql.jdbc.Driver");
		}
		
		catch(ClassNotFoundException e1)
		{
			e1.printStackTrace();
		}
		
		try
		{ 
			Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
			PreparedStatement ps= c.prepareStatement("update teachregister  set teach_name=?, teach_email=?, teach_mob_no=? ,teach_batch=? where teach_id=?");
			
			String teachname =req.getParameter("teach_name");
			
			String teachemail=req.getParameter("teach_email");
			

			String teachmobno=req.getParameter("teach_mob_no");
			String teachbatch=req.getParameter("teach_batch");
			
			
			String tid=req.getParameter("teachid");
			int no1=Integer.parseInt(tid);
			
		
			ps.setString(1,teachname);
			ps.setString(2,teachemail);
			ps.setString(3,teachmobno);
			ps.setString(4,teachbatch);
			
			
			ps.setInt(5, no1);
			ps.executeUpdate();
			System.out.println("data Updated succesfully");
			
			resp.sendRedirect("viewallteacher.jsp");
			
			} 
		

		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}