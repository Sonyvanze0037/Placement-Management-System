package com.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Company1;
import com.bean.Course1;

public class Company
{
	public static void main(String[] args) 
	{
		Configuration c= new Configuration();
		
		//
		SessionFactory sf=c.configure().buildSessionFactory();
	    //open the session
		Session session=sf.openSession();
		
		//beginig the transaction
	    Transaction tx= session.beginTransaction();
	    //create the object of class
	   // Company1 com1=  new Company1();
	    Company1 com2=  new Company1();
		
	    Company1 com3=  new Company1();
	    Company1 com4=  new Company1();
		
		   
	    //set values of properties
		/* com1.setId(1);
		 com1.setCom_name("Cognizant");
		 com1.setCom_critera("10th and 12th 50% above degree 60 % above no backlog");
		 com1.setCom_pack("4 LAKH");
		 com1.setCom_des("Software Enginer");
		*/
		 com2.setId(2);
		 com2.setCom_name("Capgemini");
		 com2.setCom_critera("10th and 12th 50% above degree 60 % above no backlog");
		 com2.setCom_pack("8 LAKH");
		 com2.setCom_des("Software Developer");
		
		 com3.setId(3);
		 com3.setCom_name("Suryalogix Pvt Ltd");
		 com3.setCom_critera("10th and 12th 50% above degree 60 % above no backlog");
		 com3.setCom_pack("2.3 LAKH");
		 com3.setCom_des("web Developer");
		
		 com4.setId(4);
		 com4.setCom_name("Xoriant");
		 com4.setCom_critera("10th and 12th 50% above degree 60 % above no backlog");
		 com4.setCom_pack("7.2 LAKH");
		 com4.setCom_des("Data Anyalst");
		
	   
	  // session.save(com1);
	   session.save(com2);
	   session.save(com3);
	   session.save(com4);
		  
	   
	    //sf.close();
	    tx.commit();
	    System.out.println("done");

	}

}
