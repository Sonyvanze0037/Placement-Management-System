package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

@WebServlet("/LoginServlet2")
public class LoginServlet2 extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 

{
	ResultSet r = null;
	String user=req.getParameter("username");
	String pass=req.getParameter("password");
	PrintWriter out=resp.getWriter();
	try
	{
		Class.forName("com.mysql.jdbc.Driver"); //load driver
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
		Statement st=c.createStatement();
		String query="select * from teachregister";
		
		r=st.executeQuery(query);
		
	
	boolean temp=true;
	
	HttpSession session= req.getSession();
	while(r.next())
	{
		if(user.equals("admin")&& pass.equals("admin"))
		{
			
		RequestDispatcher rd= req.getRequestDispatcher("Adminhome.jsp");
			rd.forward(req, resp);//data purpose 
		//	resp.sendRedirect("Adminhome.jsp");
			rd.include(req, resp);//control+data 
		}
		
			
		
		else if(user.equals(r.getString("teach_name"))&&pass.equals(r.getString("teach_pass")))
			{
				session.setAttribute("username", user);
				session.setAttribute("teach_id", r.getString("teach_id"));
				
				session.setAttribute("teach_email", r.getString("teach_email"));
				session.setAttribute("teach_mob_no", r.getString("teach_mob_no"));
				session.setAttribute("teach_batch", r.getString("teach_batch"));
				session.setAttribute("teach_course", r.getString("course_name"));
				System.out.println("login sucessfully");
				resp.sendRedirect("TeacherProfilePage.jsp");
				temp=false;
			}
			
		else if(temp==true)
		{
					
					  PrintWriter out1=resp.getWriter();
					  out1.print("LOGIN ERROR ..............!!!!!!!!!!!!!"+"LOGIN AGAIN....!!!!"+r.getString(1)); 
					  RequestDispatcher rd= req.getRequestDispatcher("Login");
					 
				//resp.sendRedirect("error.jsp");
		}
		
	}
	
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			
			if(r!=null)
				r.close();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}
	
}

}
