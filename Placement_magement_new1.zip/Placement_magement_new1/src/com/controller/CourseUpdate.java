package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/CourseUpdate")
public class CourseUpdate extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		try 
		
		{
					
			Class.forName("com.mysql.jdbc.Driver");
		}
		
		catch(ClassNotFoundException e1)
		{
			e1.printStackTrace();
		}
		
		try
		{ 
			Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
			PreparedStatement ps= c.prepareStatement("update course  set course_name=?,course_duration=?,course_completion=? where course_id=?");
			
			
			
			String coursename =req.getParameter("coursename");
			
			String courseduration=req.getParameter("courseduration");
			int courseduration1=Integer.parseInt(courseduration);

			String coursecompletion=req.getParameter("coursecompletion");
			int coursecompletion1=Integer.parseInt(coursecompletion);

			String coid=req.getParameter("couserid");
			int no1=Integer.parseInt(coid);
			
			
			
		
			ps.setString(1,coursename);
			ps.setInt(2,courseduration1);
			
			ps.setInt(3,coursecompletion1);
			ps.setInt(4, no1);
			ps.executeUpdate();
			System.out.println("data Updated succesfully");
			
			resp.sendRedirect("viewallcourse.jsp");
			
			} 
		

		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}