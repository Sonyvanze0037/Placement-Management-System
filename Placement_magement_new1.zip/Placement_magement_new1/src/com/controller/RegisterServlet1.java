package com.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/RegisterServlet1")
public class RegisterServlet1 extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
	try 
	
	{
				
		Class.forName("com.mysql.jdbc.Driver");
	}
	
	catch(ClassNotFoundException e1)
	{
		e1.printStackTrace();
	}
	
	try
	{
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
		
		PreparedStatement ps= c.prepareStatement("insert into studregister values(?,?,?,?,?,?,?,?,?,?)");
		int stud_id=0;
		int stud_attends=0;	
		String studname =req.getParameter("stud_name");
		String studemail=req.getParameter("stud_email");
		String studmbno=req.getParameter("stud_mob_no");
		String studDegree=req.getParameter("stud_degree");
		String studpassyear=req.getParameter("stud_pass_year");
		String studcourse=req.getParameter("stud_course");
		String studpass=req.getParameter("stud_pass");
		String studprofile=req.getParameter("stud_profile");
		
		
		
		ps.setInt(1, stud_id);
		ps.setString(2, studname);
		ps.setString(3, studemail);
		ps.setString(4,studmbno);
		ps.setString(5,studDegree);
		ps.setString(6,studpassyear);
		ps.setString(7,studcourse);
		ps.setString(8,studpass);
		ps.setString(9,studprofile);
		ps.setInt(10, stud_attends);
		
		ps.executeUpdate();
		System.out.println("data inserted succesfully");
		
		HttpSession session= req.getSession();
		session.setAttribute("stud_name", studname);
		
		resp.sendRedirect("Login.jsp");
		
		
		} 
	

	catch (SQLException e) 
	{
		e.printStackTrace();
	}
	
}
}
