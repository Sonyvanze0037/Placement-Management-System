package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 

{
	ResultSet r = null;
	ResultSet rs = null;
	String user=req.getParameter("username");
	String pass=req.getParameter("password");
	PrintWriter out=resp.getWriter();
	
	// check wheather user pesent i table if then show the profile
	
	
	try
	{
		Class.forName("com.mysql.jdbc.Driver"); //load driver
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
		Statement st=c.createStatement();
		String query="select * from studregister";
		r=st.executeQuery(query);
		
		
		Statement st1=c.createStatement();
		//String query1="select course_name from course where course_id = studregister.course_name  ";
		
		
		//to get data from stidents for id purpose only
		Statement st2=c.createStatement();
		ResultSet rcheck = null;
		
		rcheck = st2.executeQuery(query);
		
		if(user.equals("admin")&& pass.equals("admin"))
		{
			
		RequestDispatcher rd= req.getRequestDispatcher("Adminhome.jsp");
			rd.forward(req, resp);//data purpose 
		//	resp.sendRedirect("Adminhome.jsp");
			rd.include(req, resp);//control+data 
		}else{

			HttpSession session= req.getSession();
			String Stud_id = "";
			while(rcheck.next()){			
						
						if(user.equals(rcheck.getString("stud_name"))&&pass.equals(rcheck.getString("stud_pass")))
						{
							Stud_id =  rcheck.getString("stud_id");
												
						}
			}
			rcheck.close();
			
			//here get data from course table
			
			String query1="select c.course_name, c.course_completion from course c,studregister s where c.course_id = s.course_name and s.stud_id="+Stud_id;
			
			rs=st1.executeQuery(query1);
			
			//GET CPOURSE NAME AND SET IT TO STRING
			String course_name = "";
			
			while(rs.next()){
				course_name = rs.getString("course_name");
				session.setAttribute("course_completion", rs.getString("course_completion"));
			}
			rs.close();
			
				boolean temp=true;
				
				while(r.next())	{
					
					if(user.equals(r.getString("stud_name"))&&pass.equals(r.getString("stud_pass")))
						{
							session.setAttribute("username", user);
							session.setAttribute("stud_id", r.getString("stud_id"));
							
							session.setAttribute("stud_email", r.getString("stud_email"));
							session.setAttribute("stud_mob_no", r.getString("stud_mob_no"));
							session.setAttribute("stud_degree", r.getString("stud_degree"));
							session.setAttribute("stud_pass_year", r.getString("pass_year"));
							session.setAttribute("stud_course", course_name);
							System.out.println("login sucessfully");
							resp.sendRedirect("Stud_Home.jsp");
							temp=false;
						}
						
					else if(temp==true)
					{
								
								  PrintWriter out1=resp.getWriter();
								  out1.print("LOGIN ERROR ..............!!!!!!!!!!!!!"+"LOGIN AGAIN....!!!!"+r.getString(1)); 
								  RequestDispatcher rd= req.getRequestDispatcher("Login");
								 
							//resp.sendRedirect("error.jsp");
					}
					
				}
				
			
		}
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			
			if(r!=null)
				r.close();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}
	
}

}
