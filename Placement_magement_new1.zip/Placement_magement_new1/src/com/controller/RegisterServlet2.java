package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/RegisterServlet2")
public class RegisterServlet2 extends HttpServlet
{
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
try 
	
	{
				
		Class.forName("com.mysql.jdbc.Driver");
	}
	
	catch(ClassNotFoundException e1)
	{
		e1.printStackTrace();
	}
	
	try
	{
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/placement","root","root");
		
		PreparedStatement ps= c.prepareStatement("insert into teachregister values(?,?,?,?,?,?,?,?,?)");
		int teach_id=0;
		int teach_attends=0;	
		String teachname =req.getParameter("teach_name");
		String teachemail=req.getParameter("teach_email");
		String teachmbno=req.getParameter("teach_mob_no");
		String teachbatch=req.getParameter("teach_batch");
		String teachcourse=req.getParameter("teach_course");
		String teachpass=req.getParameter("teach_pass");
		String teachprofile=req.getParameter("teach_profile");
		
		
		
		ps.setInt(1, teach_id);
		ps.setString(2, teachname);
		ps.setString(3, teachemail);
		ps.setString(4,teachmbno);
		ps.setString(5,teachbatch);
		ps.setString(6,teachcourse);
		ps.setString(7,teachpass);
		ps.setString(8,teachprofile);
		ps.setInt(9, teach_attends);
		
		ps.executeUpdate();
		System.out.println("data inserted succesfully");
		
		HttpSession session= req.getSession();
		session.setAttribute("teach_name", teachname);
		
		resp.sendRedirect("Login1.jsp");
		
		
		} 
	

	catch (SQLException e) 
	{
		e.printStackTrace();
	}
	
}
}
