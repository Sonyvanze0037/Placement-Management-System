package com.bean;

public class Company1 
{
	int id;
	String com_name;
	String com_critera;
	String com_pack;
	String com_des;
	
	
	public String getCom_des() {
		return com_des;
	}
	public void setCom_des(String com_des) {
		this.com_des = com_des;
	}
	public String getCom_pack() {
		return com_pack;
	}
	public void setCom_pack(String com_pack) {
		this.com_pack = com_pack;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCom_name() {
		return com_name;
	}
	public void setCom_name(String com_name) {
		this.com_name = com_name;
	}
	public String getCom_critera() {
		return com_critera;
	}
	public void setCom_critera(String com_critera) {
		this.com_critera = com_critera;
	}

	
}
