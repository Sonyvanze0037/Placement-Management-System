package com.bean;

public class Course1 
{
	int id;
	String cname;
	int c_duration;
	int c_completion;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getC_duration() {
		return c_duration;
	}
	public void setC_duration(int c_duration) {
		this.c_duration = c_duration;
	}
	public int getC_completion() {
		return c_completion;
	}
	public void setC_completion(int c_completion) {
		this.c_completion = c_completion;
	}
	

}
